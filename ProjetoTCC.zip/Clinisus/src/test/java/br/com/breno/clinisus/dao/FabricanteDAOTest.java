package br.com.breno.clinisus.dao;

import org.junit.Test;

import br.com.breno.clinisus.domain.Fabricante;

public class FabricanteDAOTest {
	@Test
	public void salvar() {
		
		Fabricante	fabricante	=	new	Fabricante();
		fabricante.setFabricante("Buscopam");
		
		FabricanteDAO	fabricanteDAO	=	new	FabricanteDAO();
		fabricanteDAO.salvar(fabricante);
	}
}
