package br.com.breno.clinisus.dao;

import org.junit.Test;

import br.com.breno.clinisus.domain.Estado;

public class EstadaoDAOTest {
	@Test
	public void salvar() {
		Estado	estado	=	new	Estado();
		estado.setNome("Rio de Janeiro");
		estado.setSigla("RJ");
		
		EstadoDAO 	estadoDAO	=	new	EstadoDAO();
		estadoDAO.salvar(estado);
				
	}

}
