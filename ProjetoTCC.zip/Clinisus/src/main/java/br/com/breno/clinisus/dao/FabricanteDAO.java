package br.com.breno.clinisus.dao;

import br.com.breno.clinisus.domain.Fabricante;

public class FabricanteDAO extends GenericDAO<Fabricante> {
	
}
