package br.com.breno.clinisus.dao;

import br.com.breno.clinisus.domain.Estado;

public class EstadoDAO	extends GenericDAO<Estado> {
	
}
