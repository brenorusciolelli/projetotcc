package br.com.breno.clinisus.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
@Entity
@SuppressWarnings("serial")
public class Fabricante extends GenericDomain {
	
	@Column(length = 20, nullable = false)
	private String Fabricante;
	
	public String getFabricante() {
		return Fabricante;
	}
	
	public void setFabricante(String fabricante) {
		Fabricante = fabricante;
	}
	

}
